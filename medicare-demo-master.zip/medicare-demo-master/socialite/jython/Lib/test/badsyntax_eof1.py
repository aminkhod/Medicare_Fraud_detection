def hi():
    pass

def bye():
    hi(
