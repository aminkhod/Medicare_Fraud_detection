from java.lang import *
Class.isArray(Thread)
